const sql = require("./db.js");

// constructor
const Pengguna = function(pengguna) {
  this.nama = pengguna.nama;
  this.no_telp = pengguna.no_telp;
  this.password = pengguna.password;
};

Pengguna.create = (newUser, result) => {
  sql.query("INSERT INTO pengguna SET ?", newUser, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
    console.log("created user: ", { id_pengguna: res.insertId, ...newUser });

    const data = {
      id_pengguna: res.insertId,
      nama: newUser.nama,
      no_telp: newUser.no_telp,
    }
    result(null, data);
  });
};

Pengguna.findById = (userId, result) => {
  sql.query(`SELECT * FROM pengguna WHERE id_pengguna = ${userId}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.length) {
      console.log("found user: ", res[0]);
      const data = {
        id_pengguna: res[0].id_pengguna,
        nama: res[0].nama,
        no_telp: res[0].no_telp,
      }
      result(null, data);
      return;
    }

    // not found Customer with the id
    result({ kind: "not_found" }, null);
  });
};

Pengguna.findByName = (nama, result) => {
  sql.query(`SELECT * FROM pengguna WHERE nama LIKE '%${nama}%'`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.length) {
      console.log("found user: ", res);
      const data = [];
      res.map(item => {
        data.push({
          id_pengguna: item.id_pengguna,
          nama: item.nama,
          no_telp: item.no_telp
        })
      });
      result(null, data);
      return;
    }

    // not found Customer with the id
    result({ kind: "not_found" }, null);
  });
};

Pengguna.getAll = result => {
  sql.query("SELECT * FROM pengguna", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log("user: ", res);
    result(null, res);
  });
};

Pengguna.login = (user, result) => {
  sql.query("SELECT * FROM pengguna WHERE no_telp = ? AND password = ?", 
    [user.no_telp, user.password],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }

      if (res.length) {
        console.log("found user: ", res[0]);
        
        const data = {
          id_pengguna: res[0].id_pengguna,
          nama: res[0].nama,
          no_telp: res[0].no_telp,
        }
        result(null, data);
        return;
      }
  
      // not found Customer with the id
      result({ kind: "not_found" }, null);
  });
};

Pengguna.updateById = (id_pengguna, user, result) => {
  sql.query(
    "UPDATE pengguna SET nama = ?, no_telp = ?, password = ? WHERE id_pengguna = ?",
    [user.nama, user.no_telp, user.password, id_pengguna],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }

      if (res.affectedRows == 0) {
        // not found user with the id
        result({ kind: "not_found" }, null);
        return;
      }

      console.log("updated user: ", { id_pengguna: id_pengguna, ...user });
      const data = {
        id_pengguna: parseInt(id_pengguna),
        nama: user.nama,
        no_telp: user.no_telp,
      }
      result(null, data);
      // result(null, { id_pengguna: id_pengguna, ...user });
    }
  );
};

Pengguna.remove = (id, result) => {
  sql.query("DELETE FROM pengguna WHERE id_pengguna = ?", id, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found user with the id
      result({ kind: "not_found" }, null);
      return;
    }

    console.log("deleted user with id: ", id);
    result(null, res);
  });
};

Pengguna.removeAll = result => {
  sql.query("DELETE FROM pengguna", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log(`deleted ${res.affectedRows} user`);
    result(null, res);
  });
};

module.exports = Pengguna;