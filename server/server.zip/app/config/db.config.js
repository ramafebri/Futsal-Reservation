  module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "",
    DB: "reservasi_futsal"
  };

  // module.exports = {
  //   HOST: "localhost",
  //   USER: "appfutsa_rama",
  //   PASSWORD: "S@lv1999!",
  //   DB: "appfutsa_reservasi"
  // };  